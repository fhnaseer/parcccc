package de.tum.in.repobruegge.pom17aprilsnow.flightapp;

import org.junit.Test;

/**
 * Created by Vincent Bode on 05.07.2017.
 *
 */

public class WeatherAPITest {

    @Test
    public void testWeatherAPI() throws Exception {
        //TODO: Test disabled
//        AsyncTask<String, String, Weather> task = new WeatherTask().execute("Munich");
//        task.wait();
//        Weather result = task.get();
//        assertEquals("Weather description OK", "", result.getDescription());
    }
}
