package de.tum.in.repobruegge.pom17aprilsnow.flightapp;

import org.junit.Before;

public class FetchFlightsTaskTest {

    @Before
    public void setup() {
    }

    //@Test
    //public void fetchFlights() throws Exception {
    //    FetchFlightsTask task = new FetchFlightsTask();
    //    Collection<Flight> flights = task.fetchFlights("MUC", "TXL", "2017-07-13");
    //    for (Flight flight : flights) {
    //        assertEquals("MUC", flight.getOriginAbbreviation());
    //        assertEquals("TXL", flight.getDestinationAbbreviation());
    //    }
    //}

}
