package de.tum.in.repobruegge.pom17aprilsnow.flightapp;

import org.junit.Test;

/**
 * Created by Vincent Bode on 05.07.2017.
 *
 */

public class TimezoneAPITest {

    @Test
    public void testTimezoneAPI() throws Exception {
        //TODO: Test disabled
//        AsyncTask<String, String, String> task = new TimeZoneTask().execute("Munich");
//        task.wait();
//        String result = task.get();
//        assertEquals("Timezone description OK", "", result);
    }
}
