package de.tum.in.repobruegge.pom17aprilsnow.flightapp.Model;

/**
 * Created by Vincent Bode on 02.07.2017.
 */

public class User {
}
