package de.tum.in.repobruegge.pom17aprilsnow.flightapp.presentation.Interfaces;

import de.tum.in.repobruegge.pom17aprilsnow.flightapp.Model.Weather;

/**
 * Created by Yesika on 7/14/2017.
 */

public interface WeatherTaskDelegate {
    void setUpResult(Weather weather);
}
