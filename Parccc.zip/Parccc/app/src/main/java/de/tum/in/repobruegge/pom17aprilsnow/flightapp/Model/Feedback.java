package de.tum.in.repobruegge.pom17aprilsnow.flightapp.Model;

public class Feedback {
    private String _overallExperience;
    private String _customerService;
    private String _mealsAndBeverages;
    private String _appUsability;
    private String _entertainment;
    private String _anyOtherFeedback;

    public String getOverallExperience() {
        return _overallExperience;
    }

    public void setOverallExperience(String overallExperience) {
        _overallExperience = overallExperience;
    }

    public String getCustomerService() {
        return _customerService;
    }

    public void setCustomerService(String customerService) {
        _customerService = customerService;
    }

    public String getMealsAndBeverages() {
        return _mealsAndBeverages;
    }

    public void setMealsAndBeverages(String mealsAndBeverages) {
        _mealsAndBeverages = mealsAndBeverages;
    }

    public String getAppUsability() {
        return _appUsability;
    }

    public void setAppUsability(String appUsability) {
        _appUsability = appUsability;
    }

    public String getEntertainment() {
        return _entertainment;
    }

    public void setEntertainment(String entertainment) {
        _entertainment = entertainment;
    }

    public String get_AnyOtherFeedback() {
        return _anyOtherFeedback;
    }

    public void setAnyOtherFeedback(String anyOtherFeedback) {
        _anyOtherFeedback = anyOtherFeedback;
    }
}
